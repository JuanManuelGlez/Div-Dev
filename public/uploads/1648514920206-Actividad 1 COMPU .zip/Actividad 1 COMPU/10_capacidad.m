% Andres Acevedo, Jorge Cordoba, Diego Gonzalez
%Ejercicio 10
function capacidad
gigabytes = input("Cual es la capacidad en gigas del disco duro? ")
megabytes = gigabytes*1024
kilobytes = megabytes*1024
bytes = kilobytes*1024
fprintf("La capacidad es de %.1f megabytes o %.1f kylobytes o %.1f bytes", megabytes, kilobytes, bytes)
end
%Andres Acevedo, Jorge Cordova, Diego Gonzalez
%Ejercicio 6
c1 = input("Introduce el monto de la venta: ")
c2 = input("Introduce el monto de la venta: ")
c3 = input("Introduce el monto de la venta: ")
ct= c1+c2+c3
comision= ct*.1
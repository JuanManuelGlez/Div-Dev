% 3-Imprimir el área de un triángulo
function triangulo=area_triangulo()
a=input("Base del triángulo: ");
b=input("Altrura del triángulo: ");
area_triangulo=1/2*a*b;
display(area_triangulo)
end
% Andrés Acevedo Caracheo
% Jorge Córdova Trejo
% Diego González Aguado
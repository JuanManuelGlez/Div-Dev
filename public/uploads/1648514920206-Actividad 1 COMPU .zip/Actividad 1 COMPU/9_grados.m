% Andres Acevedo, Jorge Cordoba, Diego Gonzalez
%Ejercicio 9
function grados
f = input("Introduce los grados Fahrenheit: ")
c = (5/9)*(f-32)
fprintf("Los grados celicus son: %.1f", c)
end
% Andres Acevedo, Jorge Cordoba, Diego Gonzalez
%Ejercicio 8
function conversion
peso = input("Introduce los pesos mexicanos: ");
dolar = peso/21.8712
fprintf("los %.2f pesos son: %.2f dolares", peso, dolar)
end
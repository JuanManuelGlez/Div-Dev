% 4-Imprimir el área de un círculo
function circulo=area_circulo()
r=input("Radio del círculo: ");
area_circulo=pi*r^2;
display(area_circulo)
end
% Andrés Acevedo Caracheo
% Jorge Córdova Trejo
% Diego González Aguado
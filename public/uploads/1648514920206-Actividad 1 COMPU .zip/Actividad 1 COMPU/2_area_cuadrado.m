% 2-Imprimir el área de un cuadrado
function area=area_cuadrado()
a=input("Lado a del cuadrado: ");
b=input("Lado b del cuadrado: ");
area_cuadrado=a*b;
display(area_cuadrado)
end
% Andrés Acevedo Caracheo
% Jorge Córdova Trejo
% Diego González Aguado<
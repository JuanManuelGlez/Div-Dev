%Andres Acevedo, Jorge Cordova, Diego Gonzalez
%Ejercicio 5
r = input("Introduce el radio: ")
a = input("Introduce la altura: ")
vol = (1/3*pi)*(r^2)*(a)

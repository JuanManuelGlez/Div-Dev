%Andres Acevedo, Jorge Cordova, Diego Gonzalez
%Ejercicio 7
compra1 = input("Introduce el precio: ")
compra2 = input("Introduce el precio: ")
compra3 = input("Introduce el precio: ")
compra4 = input("Introduce el precio: ")
Total= compra1 + compra2 + compra3 + compra4 * 1.15



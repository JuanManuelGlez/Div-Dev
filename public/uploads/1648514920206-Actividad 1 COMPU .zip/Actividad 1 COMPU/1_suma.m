% 1-La suma de dos números
function suma=suma()
n=input("Inserte un número: ");
n2=input("Inserte otro número: ");
suma=n+n2;
display(suma)
end
% Andrés Acevedo Caracheo
% Jorge Córdova Trejo
% Diego González Aguado